# SPL211-Tester_Assignment_4
Tester written for the final assignment in SPL211.


Dependencies:
------------------

json-202011115.jar

sqlite-jdbc-3.8.11.2.jar

------------------

To use simply put main.py into the tester folder.



Last update
13/01/21 Added small update to handle more cases. (thanks to those who contributed)

~~12/01/21 - Fixed \n bug~~

~~12/01/21 Uploaded a new file with randomized dates.~~

~~10/1/21 9:04 - Param support added~~

~~09/01/21 22:53 - Fixed tests.txt bug~~


------------------
Check list

~~1) Add param support as required by the TA's~~
